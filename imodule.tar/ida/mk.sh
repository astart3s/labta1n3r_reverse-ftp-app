./idafree83_linux.run --mode unattended
rm -rf idafree-7.0 sample.c idafree83_linux.run
